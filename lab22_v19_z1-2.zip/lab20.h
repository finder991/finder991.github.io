#ifndef LAB20_H_INCLUDED
#define LAB20_H_INCLUDED
double lab20_v19_z1_a(double a, double b);
void lab20_v19_z1_c(double a, double *a2, double *a4, double *a5, double *a10, double *a20, double *a21);
void swap(int *a, int *b);
int processArray(int arr[], int n);
#endif // LAB20_H_INCLUDED
