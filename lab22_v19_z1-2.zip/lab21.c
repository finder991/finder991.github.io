#include <stdio.h>
#include <stdarg.h>
#include "lab21.h"

double calculate(int count, ...) {
    va_list args;
    va_start(args, count);

    double sum = 0.0;
    for (int i = 1; i <= count / 2; i++) {
        double numerator = va_arg(args, double);
        double denominator = va_arg(args, double);
        sum += numerator / denominator;
    }

    va_end(args);
    return sum;
}
