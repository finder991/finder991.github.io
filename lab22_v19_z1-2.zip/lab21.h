#ifndef LAB21_H_INCLUDED
#define LAB21_H_INCLUDED
double calculate(int count, ...);


#endif // LAB21_H_INCLUDED
