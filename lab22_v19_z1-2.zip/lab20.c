#include <math.h>
#include "lab20.h"

double lab20_v19_z1_a(double a, double b);
void lab20_v19_z1_c(double a, double *a2, double *a4, double *a5, double *a10, double *a20, double *a21);
void swap(int *a, int *b);

double lab20_v19_z1_a(double a, double b) {
    return ((2 * b - 3 + 6.8 * a) / (pow(a, 3) + b + 1)) - ((2 * pow(b, 3)) / (pow(a, 2) + pow(a, 4) + 5.7));
}


void lab20_v19_z1_c(double a, double *a2, double *a4, double *a5, double *a10, double *a20, double *a21) {
    *a2 = a * a;
    *a4 = *a2 * *a2;
    *a5 = *a4 * a;
    *a10 = *a5 * *a5;
    *a20 = *a10 * *a10;
    *a21 = *a20 * a;
}


void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}


int processArray(int arr[], int n) {
    int maxEven = -1;
    int lastOdd = -1;
    int maxEvenValue = -2147483648;

    for (int i = 0; i < n; i++) {
        if (arr[i] % 2 == 0) {
            if (arr[i] >= maxEvenValue) {
                maxEvenValue = arr[i];
                maxEven = i;
            }
        } else {
            lastOdd = i;
        }
    }

    if (maxEven == -1 || lastOdd == -1) {
        printf("����� ������ �� ���������: ������� ����� ��� ������� �������� � �����.\n");
        return 1;
    }

    swap(&arr[maxEven], &arr[lastOdd]);

    return 0;
}
