#include <string.h>
#include "str_del_ins.h"
int strdel(char*str,int from,int count){
    if(from<0) return -1;
    if(count<0) return -2;
    int len=strlen(str);
    int m=from+count;
    if(from<len){
        if(m>=len)
           str[from]=0;
        else {
            strcpy(str+from,str+m);
        }

    }
    return strlen(str);
}
int strins(char *s1,const char*s2,int to){
    int i,len1=strlen(s1);
    if(to>len1 || to<0) return -1;
    int len2=strlen(s2);
    for(i=len1; i>=to; i--) s1[i+len2]=s1[i];
    strncpy(s1+to,s2,len2);
    return strlen(s1);
}

