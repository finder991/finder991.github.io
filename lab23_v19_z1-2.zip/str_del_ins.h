#ifndef STR_DEL_INS_H_INCLUDED
#define STR_DEL_INS_H_INCLUDED
int strdel(char*,int,int);
int strins(char*,const char*,int);
#endif // STR_DEL_INS_H_INCLUDED
